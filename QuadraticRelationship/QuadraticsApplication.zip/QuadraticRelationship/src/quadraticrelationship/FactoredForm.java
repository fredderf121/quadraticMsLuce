/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quadraticrelationship;

import java.util.Scanner;

/**
 *
 * @author C35127
 */
public class FactoredForm extends QuadraticRelationship{
    public FactoredForm(){
        a=0;
        root1=0;
        root2=0;
    }
    public void userInput(){
        Scanner input = new Scanner(System.in);
        System.out.println("The value of 'a' must NOT be 0!");
        System.out.println("Please enter the a and root values for the factored equation.");
        while (true){
            this.a=getValue("a: ");
            if (a!=0) break;
            else System.out.println("\"a\" must NOT equal 0!");
        }  
        this.root1=getValue("one root: ");
        this.root2=getValue("other root: ");    
    }
    
    public double findB(){
        return (-1)*this.a*(this.root1+this.root2);
    }
    
    public double findC(){
        return a*this.root1*this.root2;
    }   
}
